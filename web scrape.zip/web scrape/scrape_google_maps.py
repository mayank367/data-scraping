
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
import time
import openpyxl
from datetime import datetime

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename = f'google_maps_data_{timestamp}.xlsx'

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Google Maps Data"
ws.append(['Name', 'Address', 'Phone Number','Email'])


service = Service('D:/web scrape/chromedriver-win64/chromedriver.exe')  
driver = webdriver.Chrome(service=service)

driver.get('https://www.google.com/maps/search/school+in+jaipur')

time.sleep(60)

scroll_pause_time = 2
last_height = driver.execute_script("return document.body.scrollHeight")

while True:
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    
    time.sleep(scroll_pause_time)
    
    new_height = driver.execute_script("return document.body.scrollHeight")
    if new_height == last_height:
        break  
    last_height = new_height

businesses = driver.find_elements(By.CLASS_NAME, 'Nv2PK')

for business in businesses:
    try:
       
        name = business.find_element(By.CLASS_NAME, 'qBF1Pd').text

        address = business.find_element(By.XPATH, ".//div[@class='W4Efsd']/div[@class='W4Efsd'][1]").text
    
    # try:    
        Email = business.find_element(By.CLASS_NAME, 'AJB7ye').text
    # except:
    #         Email = 'N/A'
        try:
            phone_number = business.find_element(By.CLASS_NAME, 'UsdlK').text
        except:
            phone_number = 'N/A'

        ws.append([name, address, phone_number,Email])
    except Exception as e:
        print(f"Error while scraping: {e}")

wb.save(filename)

driver.quit()

print(f"data succesfully save in{filename}")
